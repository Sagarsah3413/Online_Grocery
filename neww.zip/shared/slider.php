<link rel="stylesheet" href="<?php echo $sharedfolder; ?>../stylesheet/slider.css">
<div id="image">
    <style> 
        #slider div.img1 {
            background-image: url(<?php echo $sharedfolder; ?>../home/images/img2.jpeg);
        }

        #slider div.img2 {
            background-image: url(<?php echo $sharedfolder; ?>../home/images/img5.jpeg);
        }

        #slider div#img3 {
            background-image: url(<?php echo $sharedfolder; ?>../home/images/img6.jpeg);
        }
        #slider div#img4 {
            background-image: url(<?php echo $sharedfolder; ?>../home/images/img1.jpeg);
        }
    </style>
    <i id="prev">
        <img src="<?php echo $sharedfolder; ?>../home/images/prev.png" width="50px" alt="">
    </i>
    <i id="next">
        <img src="<?php echo $sharedfolder; ?>../home/images/next.png" width="50px" alt="">
    </i>
    <div id="slider">
        <div class="img1">
            <p>place order</a></p>
        </div>
        <div class="img2">
            <p>welcome to onlinebazzar</a></p>
        </div>
        <div id="img3">
            <p>now shop online</a></p>
        </div>
        <div id="img4">
            <p>add to cart</a></p>
        </div>
        <div class="img1">
            <p>place order</a></p>
        </div>
        <div class="img2">
            <p>welcome to onlinebazzar</a></p>
        </div>
    </div>
</div>