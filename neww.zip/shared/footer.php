<footer>
        <div id="footer">
            <div id="logo">
                <div><a href="<?php echo $sharedfolder; ?>../home/home.php"><img src="../home/images/logo.png" alt=""></a></div>
                <br><br>
                <p>
                At onlinebazzar we  had a variety of premium quality products (1000+)  at  numerous discounted offer. So, shop online here and get it at  your doorsteps within no time.
                </p>
            </div>
            <div id="contacts">
                <h3>Contacts</h3>
                <div class="info">
                    <div>
                        <img src="<?php echo $sharedfolder ?>../home/images/contact icon.png" alt="">
                    </div>
                    <div>
                        <h3>Call Us</h3>
                        <h4 class="foot"style="white-space: nowrap;">+977-9815739061</h4>
                    </div>  
                </div>
                <div class="info">
                    <div>
                        <img src="<?php echo $sharedfolder ?>../home/images/mail icon.png" alt="">
                    </div>
                    <div>
                        <h3>Email</h3>
                        <h4 class="foot">onlinebazzar07@gmail.com</h4>
                    </div>  
                </div>
            </div>
        </div>
        <div id="ending">
            <div class="move">2020 Copyright Online Bazzar. All rights reserved.</div>
            <div class="move" style="text-transform: capitalize;"> <a href="../contact us/contact.php"> contact us for further colabaration</a></div>
        </div>
    </footer>