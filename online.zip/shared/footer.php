<footer>
        <div id="footer">
            <div id="logo">
                    <h2><span>company</span> logo</h2>
                <br><br>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, 
                    sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                    Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                </p>
                <br>
                <img src="<?php echo $sharedfolder ?>../Images/social media icons.png" alt="social media">
            </div>
            <!-- <div id=links>
                <h3>Useful links</h3>
                <ul>
                    <li><a href="#"> All Properties</a></li>
                    <li><a href="<?php echo $sharedfolder; ?>../pricing/pricingadd.php#faq"> FAQs</a></li>
                    <li><a href="#"> Terms & Condition</a></li>
                    <li><a href="<?php echo $sharedfolder; ?>../signup and login/signup.php"> Sign Up</a></li>
                    <li><a href="<?php echo $sharedfolder; ?>../blog/bloghome.php"> Articles</a></li>
                    <li><a href="#"> Popular Tags</a></li>
                </ul>

            </div> -->
            <div id="contacts">
                <h3>Contacts</h3>
                <div class="info">
                    <div>
                        <img src="<?php echo $sharedfolder ?>../home/images/contact icon.png" alt="">
                    </div>
                    <div>
                        <h3>Call Us</h3>
                        <h4 class="foot">+92-302-000-0000</h4>
                    </div>  
                </div>
                <div class="info">
                    <div>
                        <img src="<?php echo $sharedfolder ?>../home/images/mail icon.png" alt="">
                    </div>
                    <div>
                        <h3>Email</h3>
                        <h4 class="foot" style="text-transform:uppercase;  ">www.elearning.com</h4>
                    </div>  
                </div>
            </div>
        </div>
        <div id="ending">
            <div class="move">2020 Copyright Company Name. All rights reserved.</div>
            <div class="move" style="text-transform: capitalize;"> <a href="../contact us/contact.php"> contact us for further colabaration</a></div>
        </div>
    </footer>