<?php

$dbname = 'grocers';
$dbhost = 'localhost';
$dbpass = '';
$dbuser = 'root';

$dbconnection = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
 ?>